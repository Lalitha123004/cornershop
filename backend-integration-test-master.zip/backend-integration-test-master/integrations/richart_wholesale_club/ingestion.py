import json
import numpy as np
import pandas as pd
import requests
import re

GRAND_TYPE = "client_credentials" 
CLIENT_ID = "mRkZGFjM" 
CLIENT_SECRET = "ZGVmMjMz"
base_url = f"http://0.0.0.0:5000"
keys = ['merchant_id','sku','barcodes','brand','name','description' ,'package','image_url','category','url','branch_products']

def access_token():
    endpoint_path = f"/oauth/token?client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}&grant_type={GRAND_TYPE}"
    send_url = f"{base_url}{endpoint_path}"
    r = requests.post(send_url)

    return r.json()['access_token']

def get_merchants():
    token = access_token()
    endpoint_path = f"/api/merchants?name=Richard's"
    send_url = f"{base_url}{endpoint_path}"

    payload={}
    headers = {
        'token': 'Bearer' + ' ' + str(token)
        }
    
    r = requests.request("GET", send_url, headers=headers, data=payload)
    return r.json()['id']

def change_status():
    merchant_id = get_merchants()
    token = access_token()
    endpoint_path = f"/api/merchants/{merchant_id}"
    send_url = f"{base_url}{endpoint_path}"
    payload = json.dumps({
        "can_be_deleted": False,
        "can_be_updated": False,
        "id": f"{merchant_id}",
        "is_active": True,
        "name": "Richard's"
        })
    
    headers = {
        'token': 'Bearer' + ' ' + str(token)
        }
    
    r = requests.request("PUT", send_url, headers=headers, data=payload)
    return r.json()

def delete_merchant():
    token = access_token()
    endpoint_path = f"/api/merchants?name=Beauty"
    send_url = f"{base_url}{endpoint_path}"

    payload={}
    headers = {
        'token': 'Bearer' + ' ' + str(token)
        }
    
    r = requests.request("GET", send_url, headers=headers, data=payload)
    id = r.json()['id']
    del_url = f"{base_url}/api/merchants/{id}"

    response = requests.request("DELETE", del_url, headers=headers, data=payload)

    print("Merchant deleted successfully")

def post_products():
    d=dict.fromkeys(keys)
    product_json=r"C:\Users\lalit\Documents\coding\prices.json"
    prices_json=r"C:\Users\lalit\Documents\coding\prices.json"
    json1=json.loads(product_json)
    json2=json.loads(prices_json)
    d['branch_products'].update(json2)
    d['merchant_id'].update(json1['merchant_id'])
    d['barcodes'].update(json1['barcodes'])
    d['sku'].update(json1['sku'])
    d['brand'].update(json1['brand'])
    d['name'].update(json1['name'])
    d['description'].update(json1['descritpion'])
    d['image_url'].update(json1['image_url'])
    d['category'].update(json1['category'])
    d['url'].update(json1['url'])
    d['branch_products'].update(json2)

    token = access_token()
    endpoint_path = f"/api/products"
    send_url = f"{base_url}{endpoint_path}"
    payload = json.dumps(d)
    
    headers = {
        'token': 'Bearer' + ' ' + str(token)
        }
    
    r = requests.request("POST", send_url, headers=headers, data=payload)
    return r.json()
	    


def process_csv_files():
    csv_file1 = r"C:\Users\lalit\Documents\coding\Products.csv"
    csv_file2 = r"C:\Users\lalit\Documents\coding\Price-stock.csv"
    product_data = pd.read_csv(csv_file1)
    price_data = pd.read_csv(csv_file2)
    product_data.fillna("null", inplace=True)
    product_data.fillna("null", inplace=True)
    product_data['description'] = product_data['description'].apply(lambda cw: remove_tags(cw))
    product_data['category'] = product_data['category'].str.cat(product_data['sub-category'], sep="|")
    product_data['package'] = product_data.apply(lambda x: package(x['description'], x['string']))
    barcode = pd.DataFrame(product_data['barcodes'].head()).to_numpy(dtypes='int32')
    product_data['barcodes'].fillna("barcode", inplace=True)

    options = ["RHSM", "MM"]
    for i in price_data.index:
        if price_data.loc[i, "stock"] > 0:
            price_final = price_data[(price_data['stock'] > 0) & price_data['branch'].isin(options)]
    price_final.to_json(r'C:\Users\lalit\Documents\coding\prices.json', orient='records')
    product_data.to_json(r'C:\Users\lalit\Documents\coding\products_new.json', orient='records')


def remove_tags(string):
    result = re.sub('<.*?>', '', string)
    return result


def package(string1, string2):
    if len(string2.strip()):
        result = re.search(r"[\w+ g]", string1)
    return result


if __name__ == "__main__":
    change_status()
    delete_merchant()
    process_csv_files()
